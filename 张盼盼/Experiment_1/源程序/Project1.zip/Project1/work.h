#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

class  student
{
public:
		string id;
		string name;
		int daily;
		int experiment;
		int fina;
		double  total;
		int rank;
};